
import 'package:flutter/material.dart';
import 'package:just_audio/just_audio.dart';
import 'dart:convert';
import 'package:flutter/services.dart' show rootBundle;

void main() => runApp(const MyApp());

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'المصحف إسلام صبحي بدون نت',
      theme: ThemeData(primarySwatch: Colors.green),
      home: const SurahListPage(),
      debugShowCheckedModeBanner: false,
    );
  }
}

class SurahListPage extends StatelessWidget {
  const SurahListPage({super.key});

  final List<Map<String, String>> surahs = const [
    {'name': 'الفاتحة', 'file': '001', 'index': '1'},
    {'name': 'البقرة', 'file': '002', 'index': '2'},
    {'name': 'آل عمران', 'file': '003', 'index': '3'},
    // أضف باقي السور حسب الحاجة
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('المصحف - إسلام صبحي')),
      body: ListView.builder(
        itemCount: surahs.length,
        itemBuilder: (context, index) {
          final surah = surahs[index];
          return ListTile(
            title: Text(surah['name']!),
            trailing: const Icon(Icons.play_arrow),
            onTap: () => Navigator.push(
              context,
              MaterialPageRoute(
                builder: (_) => SurahPage(
                  name: surah['name']!,
                  file: surah['file']!,
                  index: surah['index']!,
                ),
              ),
            ),
          );
        },
      ),
    );
  }
}

class SurahPage extends StatefulWidget {
  final String name;
  final String file;
  final String index;
  const SurahPage({super.key, required this.name, required this.file, required this.index});

  @override
  State<SurahPage> createState() => _SurahPageState();
}

class _SurahPageState extends State<SurahPage> {
  final AudioPlayer _player = AudioPlayer();
  List<String> ayat = [];

  @override
  void initState() {
    super.initState();
    _loadAyat();
    _player.setAsset('assets/audio/${widget.file}.mp3');
  }

  Future<void> _loadAyat() async {
    final String text = await rootBundle.loadString('assets/quran/${widget.index}.json');
    final data = jsonDecode(text);
    setState(() {
      ayat = List<String>.from(data['ayat']);
    });
  }

  @override
  void dispose() {
    _player.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text(widget.name)),
      body: Column(
        children: [
          ElevatedButton.icon(
            icon: const Icon(Icons.play_arrow),
            label: const Text('تشغيل التلاوة'),
            onPressed: () => _player.play(),
          ),
          const Divider(),
          Expanded(
            child: ListView.builder(
              itemCount: ayat.length,
              itemBuilder: (context, index) => Padding(
                padding: const EdgeInsets.all(8.0),
                child: Text(
                  ayat[index],
                  textAlign: TextAlign.right,
                  style: const TextStyle(fontSize: 20),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}
