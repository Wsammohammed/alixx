import 'package:flutter/material.dart';
import 'package:audioplayers/audioplayers.dart';

class AudioPlayerScreen extends StatefulWidget {
  final Map surah;
  AudioPlayerScreen({required this.surah});

  @override
  _AudioPlayerScreenState createState() => _AudioPlayerScreenState();
}

class _AudioPlayerScreenState extends State<AudioPlayerScreen> {
  late AudioPlayer audioPlayer;
  bool isPlaying = false;

  @override
  void initState() {
    super.initState();
    audioPlayer = AudioPlayer();
  }

  @override
  void dispose() {
    audioPlayer.dispose();
    super.dispose();
  }

  void togglePlay() async {
    if (isPlaying) {
      await audioPlayer.pause();
    } else {
      await audioPlayer.play(AssetSource('audio/${widget.surah["file"]}'));
    }
    setState(() {
      isPlaying = !isPlaying;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text(widget.surah["name"], textDirection: TextDirection.rtl)),
      body: Column(
        children: [
          Expanded(
            child: ListView.builder(
              itemCount: widget.surah["verses"].length,
              itemBuilder: (context, index) {
                return ListTile(
                  title: Text(
                    widget.surah["verses"][index],
                    textDirection: TextDirection.rtl,
                  ),
                );
              },
            ),
          ),
          ElevatedButton(
            onPressed: togglePlay,
            child: Text(isPlaying ? "إيقاف" : "تشغيل التلاوة"),
          ),
        ],
      ),
    );
  }
}