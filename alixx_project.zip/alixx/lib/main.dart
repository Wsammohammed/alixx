import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'dart:convert';
import 'audio_player.dart';

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      theme: ThemeData.dark(),
      home: SurahList(),
    );
  }
}

class SurahList extends StatefulWidget {
  @override
  _SurahListState createState() => _SurahListState();
}

class _SurahListState extends State<SurahList> {
  List surahs = [];

  @override
  void initState() {
    super.initState();
    loadSurahs();
  }

  Future<void> loadSurahs() async {
    final String response = await rootBundle.loadString('assets/surahs.json');
    final data = await json.decode(response);
    setState(() {
      surahs = data;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text("المصحف - إسلام صبحي")),
      body: ListView.builder(
        itemCount: surahs.length,
        itemBuilder: (context, index) {
          return ListTile(
            title: Text(surahs[index]["name"], textDirection: TextDirection.rtl),
            onTap: () {
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (_) => AudioPlayerScreen(surah: surahs[index]),
                ),
              );
            },
          );
        },
      ),
    );
  }
}